<?php include '../../common/view/m.header.html.php';?>
</div>
<form method='post' enctype='multipart/form-data' target='hiddenwin'>
  <h3><?php echo "BUG#$bug->id $bug->title";?></h3>
  <table class='table-1'>
    <tr>
      <td class='w-80px'><?php echo $lang->bug->assignedTo?></td>
      <td><?php echo html::select('assignedTo', $users, $bug->resolvedBy, "class='form-control'");?></td>
    </tr>
    <tr>
      <td><?php echo $lang->bug->openedBuild;?></td>
      <td><?php echo html::select('openedBuild[]', $builds, $bug->openedBuild, 'size=4 multiple=multiple class=select-3');?></td>
    </tr>
    <tr>
      <td><?php echo $lang->comment;?></td>
      <td><?php echo html::textarea('comment', '');?></td>
    </tr>
    <tr>
      <td class='text-center' colspan='2'>
      <?php echo html::submitButton($lang->bug->buttonConfirm, 'data-inline="true" data-theme="b"');?>
      <?php echo html::linkButton($lang->goback, $this->createLink('bug', 'view', "bugID=$bug->id"), 'self', "data-inline='true'");?>
      </td>
    </tr>
  </table>
</form>
<?php include '../../common/view/m.action.html.php';?>
<?php include '../../common/view/m.footer.html.php';?>
